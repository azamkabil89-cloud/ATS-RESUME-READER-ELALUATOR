# ATS Resume Analyzer

A Streamlit app that uses Google's Gemini Flash model to review a resume and return an estimated ATS compatibility score, strengths, keyword alignment, formatting concerns, and actionable improvements.

## Features

- Upload a PDF, DOCX, or TXT resume.
- Optionally paste a target job description for more useful keyword matching.
- View an estimated ATS score and explanation.
- Review strengths, missing/relevant keywords, formatting concerns, and section checks.
- Download the analysis as JSON.
- Keep the Gemini API key out of source code by using environment variables or Streamlit Secrets.

> **Important:** This score is an AI-generated estimate, not an official score from an employer's applicant tracking system. Different employers and ATS products evaluate resumes differently. The app does not guarantee an interview or job offer.

## Files

- `app.py` — Streamlit interface, document text extraction, and Gemini analysis.
- `requirements.txt` — Python dependencies.
- `README.md` — setup and deployment instructions.

## Run locally

1. Install Python 3.10 or newer.
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. Create and activate a virtual environment (recommended):

   **Windows**
   ```powershell
   py -m venv .venv
   .venv\Scripts\activate
   ```

   **macOS/Linux**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

5. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

6. Create a Gemini API key in Google AI Studio. Do not put the key directly into `app.py` or commit it to GitHub.

7. Set the key in your terminal:

   **Windows PowerShell**
   ```powershell
   $env:GEMINI_API_KEY="YOUR_GEMINI_API_KEY"
   ```

   **macOS/Linux**
   ```bash
   export GEMINI_API_KEY="YOUR_GEMINI_API_KEY"
   ```

8. Start the app:

   ```bash
   streamlit run app.py
   ```

The default model is `gemini-2.5-flash`. You can change the model in the app's sidebar to a Flash model available to your API key.

## Push to GitHub using the website UI

1. Sign in at [GitHub](https://github.com/) and click **New repository**.
2. Name it `ats-resume-analyzer`. For a first deployment, choose **Public** if you are comfortable making the source code public. Never upload resumes, API keys, or private data.
3. Create the repository.
4. In the repository, choose **Add file → Upload files**.
5. Upload `app.py`, `requirements.txt`, and `README.md` from this folder. You can also create each file using **Add file → Create new file** and paste its contents.
6. Click **Commit changes**.

## Deploy on Streamlit Community Cloud

1. Sign in to [Streamlit Community Cloud](https://share.streamlit.io/) using the GitHub account that owns the repository.
2. Click **Create app** (or **Deploy an app**).
3. Select the `ats-resume-analyzer` repository, the branch (usually `main`), and `app.py` as the main file.
4. Open the app's **Advanced settings** or **Secrets** settings before deploying, and add:

   ```toml
   GEMINI_API_KEY = "YOUR_GEMINI_API_KEY"
   ```

   Keep the actual key private. Do not paste it into GitHub files or screenshots.
5. Deploy the app and wait for dependency installation to finish.
6. If deployment fails, open the app's logs and check the first relevant error. Confirm that `requirements.txt` is in the repository root and that the secrets key name is exactly `GEMINI_API_KEY`.

## Testing checklist

- [ ] The app starts with `streamlit run app.py`.
- [ ] A text file with at least 80 characters can be analyzed.
- [ ] A valid PDF with selectable text can be analyzed.
- [ ] A DOCX file with paragraph or table text can be analyzed.
- [ ] An unsupported file type is rejected by the uploader.
- [ ] Files larger than 10 MB are rejected.
- [ ] A missing API key produces a clear error.
- [ ] The returned score is limited to 0–100.
- [ ] The JSON download contains the analysis result.

Scanned PDFs that contain only images may need OCR before their text can be extracted. API access, model availability, quotas, and billing depend on your Google AI account.
